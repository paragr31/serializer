#include "cpuinfo.h"
#include "fred.h"
